﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exam_grade1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your grade:");
            int grade = Convert.ToInt32(Console.ReadLine());

            if(grade>=90 && grade <= 100)
            {
                Console.WriteLine("your grade is A");
                Console.ReadKey();
            }
            else if (grade >= 80 && grade < 90)
            {
                Console.WriteLine("your grade is B");
                Console.ReadKey();

            }

            else if(grade>=70 && grade <= 80)
            {
                Console.WriteLine();
                Console.ReadKey();
            }

            else
            {
                Console.WriteLine("you are not pass the class");
            }



        }
    }
}
